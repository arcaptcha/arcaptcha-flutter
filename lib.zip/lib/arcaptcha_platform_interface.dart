import 'package:plugin_platform_interface/plugin_platform_interface.dart';

import 'arcaptcha_method_channel.dart';

abstract class ArcaptchaPlatform extends PlatformInterface {
  /// Constructs a ArcaptchaPlatform.
  ArcaptchaPlatform() : super(token: _token);

  static final Object _token = Object();

  static ArcaptchaPlatform _instance = MethodChannelArcaptcha();

  /// The default instance of [ArcaptchaPlatform] to use.
  ///
  /// Defaults to [MethodChannelArcaptcha].
  static ArcaptchaPlatform get instance => _instance;

  /// Platform-specific implementations should set this with their own
  /// platform-specific class that extends [ArcaptchaPlatform] when
  /// they register themselves.
  static set instance(ArcaptchaPlatform instance) {
    PlatformInterface.verifyToken(instance, _token);
    _instance = instance;
  }

  Future<String?> getPlatformVersion() {
    throw UnimplementedError('platformVersion() has not been implemented.');
  }
}
