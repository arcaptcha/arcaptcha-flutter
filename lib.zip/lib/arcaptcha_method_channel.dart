import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'arcaptcha_platform_interface.dart';

/// An implementation of [ArcaptchaPlatform] that uses method channels.
class MethodChannelArcaptcha extends ArcaptchaPlatform {
  /// The method channel used to interact with the native platform.
  @visibleForTesting
  final methodChannel = const MethodChannel('arcaptcha');

  @override
  Future<String?> getPlatformVersion() async {
    final version = await methodChannel.invokeMethod<String>('getPlatformVersion');
    return version;
  }
}
